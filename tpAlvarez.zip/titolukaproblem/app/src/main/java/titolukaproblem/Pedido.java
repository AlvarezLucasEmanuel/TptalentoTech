package titolukaproblem;

import java.util.HashMap;
import java.util.Map;

public class Pedido {
    private static int contadorId = 1;
    private int id;
    private Map<Producto, Integer> productos;
    private double costoTotal;

    public Pedido() {
        this.id = contadorId++;
        this.productos = new HashMap<>();
        this.costoTotal = 0;
    }

    public boolean agregarProducto(Producto producto, int cantidad) {
        if (producto.getCantidadStock() >= cantidad) {
            productos.put(producto, cantidad);
            costoTotal += producto.getPrecio() * cantidad;
            producto.disminuirStock(cantidad);
            return true;
        } else {
            return false;
        }
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public void mostrarPedido() {
        System.out.println("Pedido #" + id + " - Total: $" + costoTotal);
        for (Map.Entry<Producto, Integer> entry : productos.entrySet()) {
            Producto p = entry.getKey();
            System.out.println(" - " + p.getNombre() + " x" + entry.getValue() + " ($" + p.getPrecio() + " c/u)");
        }
    }
}
