package titolukaproblem;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductoService {
    private ArrayList<Producto> listaProductos = new ArrayList<>();
    private ArrayList<Pedido> listaPedidos = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void agregarProducto() {
        System.out.print("Nombre del producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        System.out.print("Cantidad en stock: ");
        int stock = scanner.nextInt();
        listaProductos.add(new Producto(nombre, precio, stock));
        System.out.println("Producto agregado correctamente.");
    }

    public void listarProductos() {
        if (listaProductos.isEmpty()) {
            System.out.println("No hay productos registrados.");
        } else {
            for (Producto p : listaProductos) {
                p.mostrarInformacion();
            }
        }
    }

    public Producto buscarProductoPorId(int id) {
        for (Producto p : listaProductos) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public Producto buscarProductoPorNombre(String nombre) {
        for (Producto p : listaProductos) {
            if (p.getNombre().equalsIgnoreCase(nombre)) return p;
        }
        return null;
    }

    public void buscarProducto() {
        System.out.print("Buscar por ID o Nombre (I/N): ");
        String opcion = scanner.nextLine();
        Producto producto = null;
        if (opcion.equalsIgnoreCase("I")) {
            System.out.print("Ingrese ID: ");
            int id = scanner.nextInt(); scanner.nextLine();
            producto = buscarProductoPorId(id);
        } else {
            System.out.print("Ingrese nombre: ");
            String nombre = scanner.nextLine();
            producto = buscarProductoPorNombre(nombre);
        }
        if (producto != null) {
            producto.mostrarInformacion();
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    public void eliminarProducto() {
        System.out.print("Ingrese ID del producto a eliminar: ");
        int id = scanner.nextInt(); scanner.nextLine();
        Producto producto = buscarProductoPorId(id);
        if (producto != null) {
            System.out.print("¿Está seguro que desea eliminar este producto? (S/N): ");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                listaProductos.remove(producto);
                System.out.println("Producto eliminado.");
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    public void crearPedido() {
        Pedido pedido = new Pedido();
        String continuar = "S";
        do {
            listarProductos();
            System.out.print("Ingrese ID del producto: ");
            int id = scanner.nextInt();
            Producto producto = buscarProductoPorId(id);
            if (producto == null) {
                System.out.println("Producto no encontrado.");
                continue;
            }
            System.out.print("Cantidad deseada: ");
            int cantidad = scanner.nextInt(); scanner.nextLine();
            if (pedido.agregarProducto(producto, cantidad)) {
                System.out.println("Producto agregado al pedido.");
            } else {
                System.out.println("Stock insuficiente.");
            }
            System.out.print("¿Desea agregar otro producto? (S/N): ");
            continuar = scanner.nextLine();
        } while (continuar.equalsIgnoreCase("S"));
        listaPedidos.add(pedido);
        System.out.println("Pedido creado exitosamente. Total: $" + pedido.getCostoTotal());
    }

    public void verPedidos() {
        if (listaPedidos.isEmpty()) {
            System.out.println("No se han realizado pedidos.");
        } else {
            for (Pedido p : listaPedidos) {
                p.mostrarPedido();
            }
        }
    }
}
